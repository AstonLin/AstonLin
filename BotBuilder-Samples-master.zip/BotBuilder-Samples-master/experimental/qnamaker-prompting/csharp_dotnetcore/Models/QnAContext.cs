﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

namespace QnAPrompting.Models
{
    public class QnAContext
    {
        public QnAPrompts[] Prompts { get; set; }
    }
}
