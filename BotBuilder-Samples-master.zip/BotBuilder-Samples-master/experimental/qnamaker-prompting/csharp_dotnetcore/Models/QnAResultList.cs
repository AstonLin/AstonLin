﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

namespace QnAPrompting.Models
{
    public class QnAResultList
    {
        public QnAResult[] Answers { get; set; }
    }
}
